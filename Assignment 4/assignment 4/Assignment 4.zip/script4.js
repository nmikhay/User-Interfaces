// Pickles Exercise
// I've provided you with some basic markup in index.html

// Please use JavaScript to select the <span> element that currently reads "Delicious"

// Change its text to read "Disgusting" USING JAVASCRIPT. Even if you are a weirdo who likes pickles, please change the text to "Disgusting". 

// Yes, you could cheat and just update the html file directly, but I hope you don't!  The goal here is to practice using JavaScript to manipulate HTML.

var span = document.querySelector("span");
span.textContent = "Disgusting";